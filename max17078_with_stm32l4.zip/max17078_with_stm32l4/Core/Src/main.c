/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "ssd1306_tests.h"
#include "ssd1306_fonts.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX17048_ADDR  (0x36 << 1)   // 8-bit address for HAL
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C2_Init(void);

/* USER CODE BEGIN PFP */
uint16_t MAX17048_ReadReg(uint8_t reg);
float    MAX17048_GetVoltage(void);
float    MAX17048_GetPercent(void);
void     MAX17048_QuickStart(void);
void     QSTART_HardwareReset(void);
void 	MAX17048_SoftReset(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C2_Init();

  /* USER CODE BEGIN 2 */
  ssd1306_Init();

  // Show that QSTART hardware reset is happening
  ssd1306_Fill(Black);
//  ssd1306_SetCursor(0, 0);
//  ssd1306_WriteString("QSTART RESET", Font_11x18, White);
//  ssd1306_UpdateScreen();

  // 1) Software QuickStart (optional)

  MAX17048_SoftReset();
  HAL_Delay(500);

 // MAX17048_QuickStart();
 // HAL_Delay(100);

  // 2) Hardware QuickStart via QSTART pin (rising edge)
 // QSTART_HardwareReset();
  //HAL_Delay(500);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      float vbat   = MAX17048_GetVoltage();
      float soc_f  = MAX17048_GetPercent();
      int   percent = (int)(soc_f + 0.5f);
      if (percent > 100) percent = 100;
      if (percent < 0)   percent = 0;

      uint16_t raw_v = MAX17048_ReadReg(0x02);  // VCELL raw

      ssd1306_Fill(Black);
      ssd1306_SetCursor(0, 0);
      ssd1306_WriteString("Battery", Font_11x18, White);

      char buf[32];

      // Raw VCELL (line 1)
      ssd1306_SetCursor(0, 0);
      sprintf(buf, "RAW:0x%04X", raw_v);
      ssd1306_WriteString(buf, Font_11x18, White);

      // Voltage line (line 2)
      ssd1306_SetCursor(0, 18);
      int mv = (int)(vbat * 100.0f);
      sprintf(buf, "V:%d.%02d", mv/100, mv%100);
      ssd1306_WriteString(buf, Font_11x18, White);

      // Percentage line (line 3)
      ssd1306_SetCursor(0, 36);
      sprintf(buf, "SOC:%3d%%", percent);
      ssd1306_WriteString(buf, Font_11x18, White);

      ssd1306_UpdateScreen();
      HAL_Delay(2000);
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x00F12981;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /* B1 User Button */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /* LD2 LED */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* QSTART on PA5 */
  GPIO_InitTypeDef GPIO_InitStruct_QSTART = {0};
  GPIO_InitStruct_QSTART.Pin = GPIO_PIN_5;
  GPIO_InitStruct_QSTART.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct_QSTART.Pull = GPIO_NOPULL;
  GPIO_InitStruct_QSTART.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct_QSTART);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET); // default LOW
}

/* USER CODE BEGIN 4 */

void QSTART_HardwareReset(void)
{
  // Rising edge pulse: LOW → HIGH → LOW
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
  HAL_Delay(10);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);   // rising edge
  HAL_Delay(10);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
  HAL_Delay(100);
}

// Read 16-bit register from MAX17048 (big endian)
uint16_t MAX17048_ReadReg(uint8_t reg)
{
  uint8_t buf[2];
  HAL_I2C_Mem_Read(&hi2c2, MAX17048_ADDR, reg, I2C_MEMADD_SIZE_8BIT,
                   buf, 2, 100);
  return (uint16_t)((buf[0] << 8) | buf[1]);
}

// Get LiPo voltage in volts
float MAX17048_GetVoltage(void)
{
  uint16_t raw = MAX17048_ReadReg(0x02);   // VCELL
  float v = ((raw >> 4) * 1.25f) / 1000.0f;
  return v;
}

// Get LiPo state of charge in %
float MAX17048_GetPercent(void)
{
  uint16_t raw = MAX17048_ReadReg(0x04);   // SOC
  uint8_t int_part  = (raw >> 8);
  uint8_t frac_part = (raw & 0xFF);
  float soc = int_part + frac_part / 256.0f;
  return soc;
}

void MAX17048_SoftReset(void) {
    uint8_t data[2] = { 0x54, 0x00 };  // 0x5400
    HAL_I2C_Mem_Write(&hi2c2, MAX17048_ADDR, 0xFE,
                      I2C_MEMADD_SIZE_8BIT, data, 2, 100);
}

void MAX17048_QuickStart(void)
{
  uint8_t data[2] = { 0x40, 0x00 }; // MODE.QS = 1
  HAL_I2C_Mem_Write(&hi2c2, MAX17048_ADDR, 0x06,
                    I2C_MEMADD_SIZE_8BIT, data, 2, 100);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
